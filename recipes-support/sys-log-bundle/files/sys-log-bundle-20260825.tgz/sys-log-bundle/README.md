# sys-log-bundle

一键打包 Ubuntu/Debian 系统日志，便于远程排查。

发版与完整操作说明见：**[发版与使用说明.md](./发版与使用说明.md)**（发布包：`sys-log-bundle-20260825.tgz`）。

## 用法

```bash
cd sys-log-bundle
sudo ./collect-syslogs.sh
sudo ./collect-syslogs.sh --days 7
sudo ./collect-syslogs.sh --out /tmp
```

默认回溯 journal **3 天**。非 root 会自动 `sudo`。

输出文件：`syslogs-<主机名>-YYYYMMDD-HHMMSS.tar.gz`

## 包内容

| 路径 | 说明 |
|------|------|
| `meta.txt` | 主机名、内核、采集时间、`--days` |
| `var/log/` | syslog / kern / dmesg / auth / boot / dpkg / Xorg / nvidia 等（含轮转） |
| `snapshots/rsyslog-status.txt` | `systemctl status/is-active` 等；运行时也会打印是否 active |
| `snapshots/dmesg.txt` | 当前 dmesg 快照 |
| `snapshots/journal-Nd.txt` | 近 N 天 journal |
| `MANIFEST.txt` | 实际收录文件与 `SKIP` 项 |

打包时若 rsyslog 非 `active`，会打 `WARN`（仍继续打包）。

不打包 `journal/` 原始库、远程桌面/打印等大目录，以及 `wtmp`/`btmp` 等二进制账本。
