#!/usr/bin/env bash
# collect-syslogs.sh — 一键打包系统日志（排查用）
# 版本: 2026-08-25
set -euo pipefail

SCRIPT_VERSION="2026-08-25"
DAYS=3
OUT_DIR="."

usage() {
  cat <<'EOF'
用法: collect-syslogs.sh [--days N] [--out DIR] [--help]

  --days N   journalctl 回溯天数（默认 3）
  --out DIR  tar.gz 输出目录（默认当前目录）
  --help     显示帮助

需要 root；非 root 会自动 sudo。
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --days)
      DAYS="${2:?--days 需要参数}"
      [[ "$DAYS" =~ ^[1-9][0-9]*$ ]] || { echo "错误: --days 须为正整数" >&2; exit 1; }
      shift 2
      ;;
    --out)
      OUT_DIR="${2:?--out 需要参数}"
      shift 2
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "未知参数: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
  exec sudo bash "$0" --days "$DAYS" --out "$OUT_DIR"
fi

OUT_DIR="$(cd "$OUT_DIR" && pwd)"
HOST="$(hostname -s 2>/dev/null || hostname)"
TS="$(date +%Y%m%d-%H%M%S)"
BUNDLE_NAME="syslogs-${HOST}-${TS}"
STAGE="$(mktemp -d "/tmp/${BUNDLE_NAME}.XXXXXX")"
BUNDLE_ROOT="${STAGE}/${BUNDLE_NAME}"
ARCHIVE="${OUT_DIR}/${BUNDLE_NAME}.tar.gz"
MANIFEST="${BUNDLE_ROOT}/MANIFEST.txt"

cleanup() {
  rm -rf "$STAGE"
}
trap cleanup EXIT

mkdir -p "${BUNDLE_ROOT}/var/log" "${BUNDLE_ROOT}/snapshots"

{
  echo "script_version=${SCRIPT_VERSION}"
  echo "hostname=${HOST}"
  echo "uname=$(uname -a)"
  echo "collected_local=$(date '+%Y-%m-%d %H:%M:%S %z')"
  echo "collected_utc=$(date -u '+%Y-%m-%d %H:%M:%S UTC')"
  echo "days=${DAYS}"
  echo "out=${ARCHIVE}"
} > "${BUNDLE_ROOT}/meta.txt"
echo "meta.txt" > "$MANIFEST"

PATTERNS=(
  "syslog*"
  "kern.log*"
  "dmesg*"
  "auth.log*"
  "boot.log*"
  "dpkg.log*"
  "apport.log*"
  "Xorg.0.log*"
  "gpu-manager*.log*"
  "nvidia-*.log*"
  "alternatives.log*"
  "ubuntu-advantage.log*"
  "fontconfig.log"
)

shopt -s nullglob
for pat in "${PATTERNS[@]}"; do
  matches=(/var/log/$pat)
  if [[ ${#matches[@]} -eq 0 ]]; then
    echo "SKIP: /var/log/${pat}" >> "$MANIFEST"
    continue
  fi
  for src in "${matches[@]}"; do
    [[ -f "$src" ]] || continue
    base="$(basename "$src")"
    cp -a "$src" "${BUNDLE_ROOT}/var/log/${base}"
    echo "var/log/${base}" >> "$MANIFEST"
  done
done
shopt -u nullglob

# rsyslog 状态（打包前先看一眼，并写入包内）
RSYSLOG_SNAP="${BUNDLE_ROOT}/snapshots/rsyslog-status.txt"
{
  echo "=== systemctl is-active rsyslog ==="
  systemctl is-active rsyslog 2>&1 || true
  echo
  echo "=== systemctl is-enabled rsyslog ==="
  systemctl is-enabled rsyslog 2>&1 || true
  echo
  echo "=== systemctl status rsyslog ==="
  systemctl status rsyslog --no-pager -l 2>&1 || true
  echo
  echo "=== rsyslogd 进程 ==="
  pgrep -a rsyslogd 2>&1 || echo "(无 rsyslogd 进程)"
} > "$RSYSLOG_SNAP"
echo "snapshots/rsyslog-status.txt" >> "$MANIFEST"

RSYSLOG_STATE="$(systemctl is-active rsyslog 2>/dev/null || true)"
if [[ "$RSYSLOG_STATE" == "active" ]]; then
  echo "rsyslog: active"
else
  echo "WARN: rsyslog 状态为 '${RSYSLOG_STATE:-unknown}'（日志文件可能未持续写入）" >&2
fi

if dmesg > "${BUNDLE_ROOT}/snapshots/dmesg.txt" 2>/dev/null; then
  echo "snapshots/dmesg.txt" >> "$MANIFEST"
else
  echo "WARN: dmesg 失败" >&2
  echo "SKIP: snapshots/dmesg.txt" >> "$MANIFEST"
fi

JOURNAL_OUT="${BUNDLE_ROOT}/snapshots/journal-${DAYS}d.txt"
if command -v journalctl >/dev/null 2>&1 \
  && journalctl -a --no-pager --since "${DAYS} days ago" > "$JOURNAL_OUT" 2>/dev/null; then
  echo "snapshots/journal-${DAYS}d.txt" >> "$MANIFEST"
else
  echo "WARN: journalctl 导出失败或不存在" >&2
  rm -f "$JOURNAL_OUT"
  echo "SKIP: snapshots/journal-${DAYS}d.txt" >> "$MANIFEST"
fi

tar -C "$STAGE" -czf "$ARCHIVE" "$BUNDLE_NAME"
trap - EXIT
cleanup

SIZE="$(du -h "$ARCHIVE" | awk '{print $1}')"
echo "已生成: ${ARCHIVE} (${SIZE})"
