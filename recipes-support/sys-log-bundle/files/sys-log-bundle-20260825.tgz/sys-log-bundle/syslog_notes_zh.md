# Syslog / rsyslog 小结

## 是什么

**Syslog** 是系统日志机制：程序/内核把日志发给日志服务，由服务统一分类并写入文件或转发。

Ubuntu/Debian 上常见实现是 **rsyslog**（进程名 `rsyslogd`）。

```
应用程序 / 内核 / 守护进程
          │
          ▼
    ┌─────────────┐
    │  rsyslogd   │
    └──────┬──────┘
           │
     ┌─────┼─────┬──────────┐
     ▼     ▼     ▼          ▼
  syslog kern.log auth.log  远程服务器...
```

---

## Facility + Priority

### Facility（来源）

| Facility | 含义 | 常见文件 |
|----------|------|----------|
| `kern` | 内核 | `kern.log` |
| `auth` / `authpriv` | 认证/安全 | `auth.log` |
| `daemon` | 守护进程 | `syslog` |
| `user` | 用户程序 | `syslog` |
| `mail` | 邮件 | `mail.log` |
| `cron` | 定时任务 | `syslog` / `cron.log` |
| `local0`–`local7` | 自定义 | 可自行配置 |

### Priority（严重级别，从高到低）

`emerg` → `alert` → `crit` → `err` → `warning` → `notice` → `info` → `debug`

示例：`kern.err` = 内核错误及以上；`*.info` = 所有来源的 info 及以上。

---

## 工作流程

1. **产生**：内核进环形缓冲区；应用通过 `syslog()` / journald 等上报  
2. **分类**：rsyslog 按 facility / priority / 程序名匹配规则  
3. **输出**：写本地文件、控制台，或转发远程 / 数据库  

---

## Ubuntu 上常见日志文件

| 文件 | 内容 |
|------|------|
| `/var/log/syslog` | 总日志（接近传统 `/var/log/messages`） |
| `/var/log/kern.log` | 仅内核 |
| `/var/log/auth.log` | 登录、sudo、ssh 等 |
| `/var/log/dmesg` | 启动时内核缓冲区快照 |

> Debian/Ubuntu **默认没有** `/var/log/messages`，文档里写的 `messages` 应对应 `syslog`。

---

## dmesg / kern.log / syslog 对比

```
内核消息 ──► 环形缓冲区 ──► dmesg
                 │
                 ▼ rsyslog
        ┌────────┴────────┐
        │                 │
   kern.log           syslog
   （只记内核）      （记几乎所有）
```

| | `dmesg` | `kern.log` | `syslog` |
|---|---------|------------|----------|
| 范围 | 仅内核 | 仅内核 | 内核 + 服务/应用 |
| 存储 | 内存 | 磁盘 | 磁盘 |
| 持久性 | 重启清空；缓冲区满会覆盖 | 持久，可轮转 | 持久，可轮转 |
| 用途 | 立刻看最新内核输出 | 内核历史排查 | 整机总日志 |

关系简述：`kern.log` 的内容通常也是 `syslog` 的子集（内核部分重叠）。

---

## 与 systemd-journald

现代 Ubuntu 上两者常并存：

```
程序/内核 → journald（journalctl）
                │ 可转发
                ▼
             rsyslog（/var/log/* 文本日志）
```

---

## 配置位置

| 路径 | 作用 |
|------|------|
| `/etc/rsyslog.conf` | 主配置 |
| `/etc/rsyslog.d/*.conf` | 额外规则 |
| `/etc/logrotate.d/*` | 日志轮转 |

典型规则示例：

```
kern.*                         /var/log/kern.log
*.*;auth,authpriv.none         -/var/log/syslog
auth,authpriv.*                /var/log/auth.log
```

路径前的 `-` 表示异步写盘（更快，异常掉电时可能丢最后几行）。

`rsyslogd was HUPed`：通常是 logrotate 切完日志后，通知 rsyslog 重新打开文件，属正常现象。

---

## 常用命令

```bash
# 服务状态
systemctl status rsyslog

# 重启 / 重载
sudo systemctl restart rsyslog
sudo systemctl reload rsyslog

# 实时查看
tail -f /var/log/syslog
tail -f /var/log/kern.log

# 发一条测试消息
logger "hello from logger"
```

---

## 与 EtherCAT 排查

EtherCAT 主站是内核模块，日志路径大致为：

```
ec_master 打印 → 环形缓冲区(dmesg) → rsyslog(kern.*) → kern.log / syslog
```

推荐：

```bash
dmesg | grep -i ethercat
grep -i ethercat /var/log/kern.log
grep -i ethercat /var/log/syslog
```

文档中的：

```bash
tail -2 /var/log/messages
```

在 Ubuntu 上应改为：

```bash
tail -2 /var/log/syslog
```

---

## 一句话

**rsyslog = 系统的日志邮局**：按来源和级别分类投递；Ubuntu 上总日志看 `syslog`，内核看 `kern.log` / `dmesg`，没有传统的 `messages`。
