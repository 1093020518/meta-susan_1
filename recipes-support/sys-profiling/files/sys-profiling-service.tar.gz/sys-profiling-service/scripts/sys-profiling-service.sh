#!/usr/bin/env bash
# 管理系统 profiling 采集的 systemd --user 服务
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
UNIT_NAME="sys-profiling.service"
UNIT_TEMPLATE="${ROOT}/systemd/${UNIT_NAME}.in"
UNIT_DIR="${HOME}/.config/systemd/user"
UNIT_DST="${UNIT_DIR}/${UNIT_NAME}"
LEGACY_UNITS=(
  "${UNIT_DIR}/glances-record.service"
  "${UNIT_DIR}/glances-csv-export.service"
)

usage() {
  cat <<EOF
用法: $(basename "$0") <install|uninstall|start|stop|restart|status>

  install    安装并 enable --now（登录后自启）
  uninstall  停止并移除 unit
  start      启动 sys-profiling 采集
  stop       停止 sys-profiling 采集
  restart    重启 sys-profiling 采集
  status     查看服务状态

开机不等登录也要跑时，再执行（可选）:
  sudo loginctl enable-linger \$USER
EOF
}

require_unit() {
  if [[ ! -f "${UNIT_DST}" ]]; then
    echo "未安装 unit: ${UNIT_DST}"
    echo "请先: $(basename "$0") install"
    exit 1
  fi
}

remove_legacy_units() {
  local legacy
  for legacy in "${LEGACY_UNITS[@]}"; do
    local name
    name="$(basename "${legacy}")"
    if [[ -f "${legacy}" ]]; then
      systemctl --user disable --now "${name}" 2>/dev/null || true
      rm -f "${legacy}"
    fi
  done
}

cmd="${1:-}"
case "${cmd}" in
  install)
    [[ -f "${UNIT_TEMPLATE}" ]] || { echo "缺少模板: ${UNIT_TEMPLATE}"; exit 1; }
    [[ -x "${ROOT}/scripts/record-sys-profiling.sh" ]] || chmod +x "${ROOT}/scripts/record-sys-profiling.sh"
    remove_legacy_units
    mkdir -p "${UNIT_DIR}"
    sed "s|__ROOT__|${ROOT}|g" "${UNIT_TEMPLATE}" > "${UNIT_DST}"
    systemctl --user daemon-reload
    systemctl --user enable --now "${UNIT_NAME}"
    echo "已安装并启动: ${UNIT_DST}"
    echo "查看: systemctl --user status ${UNIT_NAME}"
    echo "日志: journalctl --user -u ${UNIT_NAME} -f"
    ;;
  uninstall)
    systemctl --user disable --now "${UNIT_NAME}" 2>/dev/null || true
    remove_legacy_units
    rm -f "${UNIT_DST}"
    systemctl --user daemon-reload
    echo "已卸载 ${UNIT_NAME}"
    ;;
  start)
    require_unit
    systemctl --user start "${UNIT_NAME}"
    echo "已启动 ${UNIT_NAME}"
    systemctl --user --no-pager --full status "${UNIT_NAME}" || true
    ;;
  stop)
    require_unit
    systemctl --user stop "${UNIT_NAME}"
    echo "已停止 ${UNIT_NAME}"
    systemctl --user --no-pager --full status "${UNIT_NAME}" || true
    ;;
  restart)
    require_unit
    systemctl --user restart "${UNIT_NAME}"
    echo "已重启 ${UNIT_NAME}"
    systemctl --user --no-pager --full status "${UNIT_NAME}" || true
    ;;
  status)
    systemctl --user status "${UNIT_NAME}" --no-pager || true
    ;;
  *)
    usage
    exit 1
    ;;
esac
