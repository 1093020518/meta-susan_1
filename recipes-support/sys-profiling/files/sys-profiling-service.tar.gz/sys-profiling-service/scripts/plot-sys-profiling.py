#!/usr/bin/env python3
"""用 matplotlib 按分类绘制系统 profiling 监控图。

用法:
  python3 plot-sys-profiling.py
  python3 plot-sys-profiling.py ../data/csv/glances-20260824-201300.csv
  python3 plot-sys-profiling.py glances.csv --cols cpu.total mem.percent
  python3 plot-sys-profiling.py --list-cols
  python3 plot-sys-profiling.py glances.csv -o /tmp/out.png
  python3 plot-sys-profiling.py glances.csv --output-dir ~/plots
  python3 plot-sys-profiling.py glances.csv --show

默认保存到 data/plots/<csv 文件名>.png；可用 --output-dir / 环境变量
GLANCES_PLOT_DIR 改目录，-o 指定完整路径，--show 仅弹窗不落盘。
"""

from __future__ import annotations

import argparse
import csv
import os
import re
from pathlib import Path

import pandas as pd

# 图例友好名（CSV 列名 -> 显示名；用英文避免缺字）
COL_LABELS: dict[str, str] = {
    "cpu.total": "total %",
    "cpu.user": "user %",
    "cpu.system": "system %",
    "mem.percent": "used %",
    "load.min1": "1m",
    "load.min5": "5m",
    "load.min15": "15m",
    "gpu.nvidia0.proc": "NVIDIA util %",
    "gpu.nvidia0.mem": "NVIDIA VRAM %",
    "gpu.nvidia0.temperature": "NVIDIA temp C",
    "gpu.intel0.proc": "Intel util %",
    "gpu.intel0.mem": "Intel mem %",
    "gpu.intel0.temperature": "Intel temp C",
    "sensors.Package id 0.value": "CPU Package id 0 C",
}

# 分类面板：(标题, 纵轴单位说明, 候选列)；GPU/TEMP 会按 CSV 动态补全
CATEGORIES: list[tuple[str, str, list[str]]] = [
    ("CPU", "%", ["cpu.total", "cpu.user", "cpu.system"]),
    ("MEM", "%", ["mem.percent"]),
    ("LOAD", "load", ["load.min1", "load.min5", "load.min15"]),
    ("GPU", "%", ["gpu.nvidia0.proc", "gpu.nvidia0.mem"]),
    (
        "TEMP",
        "°C",
        ["sensors.Package id 0.value", "gpu.nvidia0.temperature"],
    ),
]

_AMP_RESULT_RE = re.compile(
    r"CPU:\s*([0-9]+(?:\.[0-9]+)?)\s*%\s*\|\s*MEM:\s*([0-9]+(?:\.[0-9]+)?)\s*%",
    re.IGNORECASE,
)


def read_glances_csv(path: Path) -> pd.DataFrame:
    """读取 Glances CSV：列数变化时按表头对齐，不丢行。"""
    with path.open(newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise SystemExit(f"空 CSV: {path}") from None

        n = len(header)
        rows: list[list[str | None]] = []
        padded = truncated = 0
        for row in reader:
            if not row:
                continue
            if len(row) < n:
                row = row + [None] * (n - len(row))
                padded += 1
            elif len(row) > n:
                row = row[:n]
                truncated += 1
            rows.append(row)

    if padded or truncated:
        print(
            f"提示: CSV 列数有变化，已对齐表头 "
            f"(短行补齐 {padded}，长行截断 {truncated})"
        )

    return expand_amp_result_columns(pd.DataFrame(rows, columns=header))


def expand_amp_result_columns(df: pd.DataFrame) -> pd.DataFrame:
    """amps.Xxx.result -> app.Xxx.cpu / cpu_host / cpu_avg / mem。

    - cpu: 匹配进程 CPU% 加总（单核=100，可 >100）
    - cpu_host: cpu / 逻辑核数 → 占整机 CPU 的百分比（与顶栏 cpu.total 同量纲）
    - cpu_avg: cpu / 进程数
    - mem: 匹配进程内存占物理内存% 的加总（已是整机比例）
    """
    ncpu = float(os.cpu_count() or 1)
    for col in list(df.columns):
        if not (col.startswith("amps.") and col.endswith(".result")):
            continue
        name = col[len("amps.") : -len(".result")]
        cpu_col = f"app.{name}.cpu"
        cpu_host_col = f"app.{name}.cpu_host"
        cpu_avg_col = f"app.{name}.cpu_avg"
        mem_col = f"app.{name}.mem"
        count_col = f"amps.{name}.count"
        cpus: list[float | None] = []
        mems: list[float | None] = []
        for val in df[col]:
            if val is None or (isinstance(val, float) and pd.isna(val)):
                cpus.append(None)
                mems.append(None)
                continue
            m = _AMP_RESULT_RE.search(str(val))
            if not m:
                cpus.append(None)
                mems.append(None)
                continue
            cpus.append(float(m.group(1)))
            mems.append(float(m.group(2)))
        cpu_s = pd.Series(cpus, dtype="float64")
        mem_s = pd.Series(mems, dtype="float64")
        # AMP 在进程退出后 count=0 时 result 常残留旧值，按 count 清掉
        if count_col in df.columns:
            counts = pd.to_numeric(df[count_col], errors="coerce")
            alive = counts.fillna(0) > 0
            cpu_s = cpu_s.where(alive)
            mem_s = mem_s.where(alive)
            df[cpu_avg_col] = (cpu_s / counts).where(alive)
        else:
            df[cpu_avg_col] = cpu_s
        df[cpu_col] = cpu_s
        df[cpu_host_col] = cpu_s / ncpu
        df[mem_col] = mem_s
        COL_LABELS[cpu_col] = f"{name} cpu sum%"
        COL_LABELS[cpu_host_col] = f"{name} cpu % of host"
        COL_LABELS[cpu_avg_col] = f"{name} cpu avg%"
        COL_LABELS[mem_col] = f"{name} mem %"
    return df


def discover_gpu_columns(columns: list[str]) -> list[str]:
    """收集所有 gpu.*.proc / gpu.*.mem，优先 NVIDIA 再其它。"""

    def _key_rank(key: str) -> tuple[int, str]:
        if key.startswith("nvidia"):
            return (0, key)
        if key.startswith("intel"):
            return (1, key)
        return (2, key)

    keys = {
        c.split(".")[1]
        for c in columns
        if re.fullmatch(r"gpu\.[^.]+\.(proc|mem)", c)
    }
    found: list[str] = []
    for key in sorted(keys, key=_key_rank):
        for suffix in ("proc", "mem"):
            col = f"gpu.{key}.{suffix}"
            if col not in columns:
                continue
            found.append(col)
            if col not in COL_LABELS:
                kind = "util" if suffix == "proc" else "mem"
                COL_LABELS[col] = f"{key} {kind} %"
    return found


def discover_temp_columns(columns: list[str]) -> list[str]:
    preferred = [
        "sensors.Package id 0.value",
        "gpu.nvidia0.temperature",
        "gpu.intel0.temperature",
    ]
    found = [c for c in preferred if c in columns]
    extras = sorted(
        c
        for c in columns
        if re.fullmatch(r"gpu\.[^.]+\.temperature", c) and c not in found
    )
    for col in extras:
        key = col.split(".")[1]
        COL_LABELS.setdefault(col, f"{key} temp C")
    return found + extras


def discover_app_columns(columns: list[str]) -> tuple[list[str], list[str]]:
    # 优先整机占比，便于和顶栏 CPU% 对比，无需知道进程数
    amp_host = sorted(
        c for c in columns if c.startswith("app.") and c.endswith(".cpu_host")
    )
    amp_avg = sorted(
        c for c in columns if c.startswith("app.") and c.endswith(".cpu_avg")
    )
    amp_cpu = sorted(
        c
        for c in columns
        if c.startswith("app.")
        and c.endswith(".cpu")
        and not c.endswith(".cpu_avg")
        and not c.endswith(".cpu_host")
    )
    amp_mem = sorted(
        c for c in columns if c.startswith("app.") and c.endswith(".mem")
    )
    if amp_host:
        return amp_host, amp_mem
    if amp_avg:
        return amp_avg, amp_mem
    if amp_cpu or amp_mem:
        return amp_cpu, amp_mem
    cpu_cols = sorted(
        c
        for c in columns
        if c.startswith("processlist.") and c.endswith(".cpu_percent")
    )
    mem_cols = sorted(
        c
        for c in columns
        if c.startswith("processlist.") and c.endswith(".memory_percent")
    )
    return cpu_cols, mem_cols


def apply_percent_ylim(
    ax, series_list: list[pd.Series], title: str
) -> None:
    """百分比纵轴上下留白，避免 0%/100% 贴边框。"""
    vals = pd.concat(series_list, ignore_index=True).dropna()
    data_max = float(vals.max()) if not vals.empty else 100.0
    data_min = float(vals.min()) if not vals.empty else 0.0

    y_bottom = min(-8.0, data_min - 8.0)
    if title in ("GPU", "APP MEM", "APP CPU", "CPU", "MEM"):
        y_top = max(115.0, data_max + 15.0)
    else:
        y_top = max(115.0, data_max + 10.0)

    ax.set_ylim(y_bottom, y_top)

    if y_top <= 140:
        ticks = [0, 25, 50, 75, 100]
        if y_top >= 115:
            ticks.append(110)
        ax.set_yticks([t for t in ticks if y_bottom <= t <= y_top])
    else:
        step = max(50.0, round(y_top / 5.0 / 50.0) * 50.0)
        ticks = [0.0]
        t = step
        while t < y_top:
            ticks.append(t)
            t += step
        ax.set_yticks(ticks)

    if 100 < y_top <= 200:
        ax.axhline(100, color="0.55", linewidth=0.8, linestyle="--", zorder=0)


def find_time_column(columns: list[str]) -> str:
    for name in ("timestamp", "now", "time"):
        if name in columns:
            return name
    raise SystemExit(f"找不到时间列，现有列: {columns[:20]}...")


def latest_csv(csv_dir: Path) -> Path:
    candidates = sorted(
        csv_dir.glob("glances-*.csv"), key=lambda p: p.stat().st_mtime
    )
    if not candidates:
        legacy = csv_dir / "glances-overview.csv"
        if legacy.exists():
            return legacy
        raise SystemExit(f"目录中没有 glances-*.csv: {csv_dir}")
    return candidates[-1]


def _pid_from_process_col(col: str) -> str | None:
    parts = col.split(".")
    if len(parts) >= 3 and parts[0] == "processlist" and parts[1].isdigit():
        return parts[1]
    return None


def app_series_label(df: pd.DataFrame, metric_col: str) -> str:
    if metric_col.startswith("app."):
        return COL_LABELS.get(metric_col, metric_col)
    pid = _pid_from_process_col(metric_col)
    if not pid:
        return metric_col
    name_col = f"processlist.{pid}.name"
    metric = "cpu" if metric_col.endswith(".cpu_percent") else "mem"
    if name_col in df.columns:
        names = df[name_col].dropna().astype(str)
        names = names[names.str.len() > 0]
        if not names.empty:
            return f"{names.mode().iloc[0]}[{pid}] {metric}%"
    return f"pid:{pid} {metric}%"


def resolve_panels(
    columns: list[str], cols: list[str] | None
) -> list[tuple[str, str, list[str]]]:
    if cols:
        present = [c for c in cols if c in columns]
        missing = [c for c in cols if c not in columns]
        if missing:
            raise SystemExit(f"列不存在: {missing}\n可用列可用 --list-cols 查看")
        if not present:
            raise SystemExit("没有可画的列")
        return [("Custom", "", present)]

    panels: list[tuple[str, str, list[str]]] = []
    for title, unit, preferred in CATEGORIES:
        if title == "GPU":
            found = discover_gpu_columns(columns)
        elif title == "TEMP":
            found = discover_temp_columns(columns)
        else:
            found = [c for c in preferred if c in columns]
        if found:
            panels.append((title, unit, found))

    app_cpu, app_mem = discover_app_columns(columns)
    if app_cpu:
        panels.append(("APP CPU", "%", app_cpu))
    if app_mem:
        panels.append(("APP MEM", "%", app_mem))

    if not panels:
        raise SystemExit("CSV 中找不到 CPU/MEM/LOAD/GPU/TEMP/APP 相关列")
    return panels


def default_plot_dir(root: Path) -> Path:
    env = os.environ.get("GLANCES_PLOT_DIR", "").strip()
    if env:
        return Path(env).expanduser()
    return root / "data" / "plots"


def resolve_output_path(
    csv_path: Path,
    root: Path,
    output: str | None,
    output_dir: str | None,
    show: bool,
) -> Path | None:
    if show:
        return None
    if output:
        return Path(output).expanduser()
    plot_dir = (
        Path(output_dir).expanduser() if output_dir else default_plot_dir(root)
    )
    return plot_dir / f"{csv_path.stem}.png"


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    csv_dir = root / "data" / "csv"

    parser = argparse.ArgumentParser(description="Plot system profiling metrics CSV")
    parser.add_argument("csv", nargs="?", default=None, help="CSV 路径")
    parser.add_argument("--cols", nargs="+", default=None, help="自定义列")
    parser.add_argument("-o", "--output", default=None, help="保存图片路径")
    parser.add_argument("--output-dir", default=None, help="图片目录")
    parser.add_argument("--show", action="store_true", help="仅弹窗")
    parser.add_argument("--list-cols", action="store_true", help="只打印列名")
    args = parser.parse_args()

    csv_path = Path(args.csv) if args.csv else latest_csv(csv_dir)
    if not csv_path.exists():
        raise SystemExit(f"文件不存在: {csv_path}")

    df = read_glances_csv(csv_path)
    if args.list_cols:
        print("\n".join(df.columns.tolist()))
        return

    time_col = find_time_column(df.columns.tolist())
    df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=[time_col]).sort_values(time_col)

    panels = resolve_panels(df.columns.tolist(), args.cols)
    out = resolve_output_path(
        csv_path, root, args.output, args.output_dir, args.show
    )

    try:
        import matplotlib

        if out is not None:
            matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        raise SystemExit(
            "请先安装: pip3 install --user -r requirements.txt"
        ) from None

    fig, axes = plt.subplots(
        len(panels), 1, sharex=True, figsize=(12, 2.6 * len(panels))
    )
    if len(panels) == 1:
        axes = [axes]

    for ax, (title, unit, cols) in zip(axes, panels):
        plotted: list[pd.Series] = []
        for col in cols:
            series = pd.to_numeric(df[col], errors="coerce")
            if series.notna().sum() == 0:
                continue
            plotted.append(series)
            label = (
                app_series_label(df, col)
                if title.startswith("APP")
                else COL_LABELS.get(col, col)
            )
            ax.plot(df[time_col], series, linewidth=1.2, label=label)
        if not plotted:
            ax.text(
                0.5,
                0.5,
                "no data",
                transform=ax.transAxes,
                ha="center",
                va="center",
                color="0.5",
            )
            continue
        ax.set_ylabel(f"{title} ({unit})" if unit else title)
        ax.legend(loc="upper left", fontsize=8)
        ax.grid(True, alpha=0.3)
        if unit == "%":
            apply_percent_ylim(ax, plotted, title)

    axes[-1].set_xlabel(time_col)
    fig.suptitle(f"Glances: {csv_path.name}")
    fig.autofmt_xdate()
    fig.tight_layout()

    if out is not None:
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=140, bbox_inches="tight", pad_inches=0.25)
        print(f"已保存: {out.resolve()}")
    else:
        plt.show()


if __name__ == "__main__":
    main()
