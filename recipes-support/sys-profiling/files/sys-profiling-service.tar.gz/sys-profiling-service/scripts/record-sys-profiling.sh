#!/usr/bin/env bash
# 持续记录系统 profiling 指标到 CSV（默认 1s，文件名带启动时间）
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CONF="${ROOT}/cfg/glances/glances.conf"
OUT_DIR="${ROOT}/data/csv"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="${OUT_DIR}/glances-${STAMP}.csv"
INTERVAL="${1:-1}"

mkdir -p "${OUT_DIR}"

if command -v glances >/dev/null 2>&1; then
  BIN=(glances)
elif python3 -m glances --help >/dev/null 2>&1; then
  BIN=(python3 -m glances)
else
  echo "未找到 glances。请安装: pip3 install --user -r ${ROOT}/requirements.txt"
  exit 1
fi

echo "写入: ${OUT_FILE}"
echo "间隔: ${INTERVAL}s  （Ctrl+C 停止）"
echo "提示: 本次运行写入新文件（--export-csv-overwrite）"

exec "${BIN[@]}" \
  -C "${CONF}" \
  --quiet \
  --export csv \
  --export-csv-file "${OUT_FILE}" \
  --export-csv-overwrite \
  --time "${INTERVAL}"
