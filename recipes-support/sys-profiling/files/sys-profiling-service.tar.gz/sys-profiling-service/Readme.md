# glances-persist 发板说明

系统 profiling 采集（Glances → CSV）+ 出图。可与 `stress_test_package` 同机使用：一边加压，一边落盘指标。

## 1. 包内容

| 路径 | 作用 |
|---|---|
| `cfg/glances/glances.conf` | Glances 配置（CPU/GPU/MEM + AMP 匹配 stress / gpu_burn） |
| `scripts/record-sys-profiling.sh` | 前台采集，写 `data/csv/glances-<时间戳>.csv` |
| `scripts/sys-profiling-service.sh` | systemd --user 安装/启停 |
| `scripts/plot-sys-profiling.py` | 读 CSV 出图到 `data/plots/` |
| `systemd/sys-profiling.service.in` | user unit 模板 |
| `requirements.txt` | pip 依赖 |

发布包**不含**本机 `data/csv`、`data/plots` 历史文件。

产物（宿主机）：

```text
~/Work/glances-persist.tar.gz
```

## 2. 拷到板子

示例：`niic@172.16.100.151`（按实际改）。

```bash
# 宿主机
scp ~/Work/glances-persist.tar.gz niic@172.16.100.151:~/

# 板子
ssh niic@172.16.100.151
tar -xzf glances-persist.tar.gz
cd glances-persist
```

## 3. 上板安装依赖

建议用用户级 pip（与 systemd unit 里的 `~/.local/bin` 一致）：

```bash
cd ~/glances-persist
python3 -m pip install --user -U pip
python3 -m pip install --user -r requirements.txt
```

依赖要点：

- `glances[all]`：采集与 CSV 导出  
- `nvidia-ml-py`：NVIDIA GPU 指标（无独显可装，读不到 GPU 列即可）  
- `pandas` / `matplotlib`：出图  

验证：

```bash
command -v glances || python3 -m glances --help
nvidia-smi   # 有 NVIDIA 时
```

## 4. 启动采集

### 方式 A：一次性前台（调试）

```bash
./scripts/record-sys-profiling.sh        # 默认 1s
./scripts/record-sys-profiling.sh 2      # 2s 间隔
# Ctrl+C 停止；每次启动新建 glances-YYYYMMDD-HHMMSS.csv
```

### 方式 B：systemd --user（推荐长期跑）

```bash
chmod +x scripts/*.sh
./scripts/sys-profiling-service.sh install   # enable --now
./scripts/sys-profiling-service.sh status
journalctl --user -u sys-profiling.service -f
```

常用：

```bash
./scripts/sys-profiling-service.sh stop
./scripts/sys-profiling-service.sh start
./scripts/sys-profiling-service.sh restart
./scripts/sys-profiling-service.sh uninstall
```

开机不等图形登录也要采时（可选）：

```bash
sudo loginctl enable-linger "$USER"
```

## 5. 与压测联调

1. 先装并启动 glances-persist 采集  
2. 再跑 `stress_test_package`：`./run_stress.sh --all`  
3. AMP 会匹配 `.*stress.*` / `.*gpu_burn.*`，CSV 中有稳定列（如 `amps.Stress.*`、`amps.Gpuburn.*`）  
4. 停测后可继续采一段，再停 profiling 服务  

## 6. 出图

```bash
# 默认取 data/csv 下最新 csv，图写到 data/plots/
python3 scripts/plot-sys-profiling.py

# 指定文件
python3 scripts/plot-sys-profiling.py data/csv/glances-20260826-170844.csv

# 列名 / 自定义输出
python3 scripts/plot-sys-profiling.py --list-cols
python3 scripts/plot-sys-profiling.py data/csv/xxx.csv -o /tmp/out.png
```

无显示器时不要加 `--show`；把 `data/plots/*.png` 拷回宿主机查看即可。

## 7. 配置按需微调

编辑 `cfg/glances/glances.conf` 后**重启采集**（前台重跑或 `sys-profiling-service.sh restart`）。

常见项：

| 段 | 说明 |
|---|---|
| `[network] hide=` | 隐藏无关网卡（板子接口名可能不同） |
| `[diskio] hide=` | 隐藏分区盘符噪声 |
| `[amp_stress]` / `[amp_gpuburn]` | 压测进程正则；改名需同步改 |
| `[sensors]` | 温度；Jetson/不同机型传感器名可能变 |

改完 unit 路径或脚本后若已 install，再执行一次 `install` 或 `daemon-reload` + `restart`。

## 8. 上板验收清单

- [ ] `pip install --user -r requirements.txt` 成功  
- [ ] `glances` 或 `python3 -m glances` 可用  
- [ ] `./scripts/record-sys-profiling.sh` 能写出新 CSV，Ctrl+C 正常停  
- [ ] （可选）`sys-profiling-service.sh install` 后 `status` 为 active  
- [ ] 压测运行时 CSV 中出现 GPU / AMP 相关列（有 NVIDIA / 有 stress 时）  
- [ ] `plot-sys-profiling.py` 能生成 png  

## 9. 常见问题

**服务起不来 / 找不到 glances**  
确认 `~/.local/bin` 在 PATH；unit 已写 `Environment=PATH=%h/.local/bin:...`。用 `journalctl --user -u sys-profiling.service -n 50` 看报错。

**CSV 无 GPU 列**  
无 NVIDIA、驱动未装，或 `nvidia-ml-py` 未装。先 `nvidia-smi`，再重装 requirements 并重启采集。

**CSV 列错位、画图丢行**  
不要开启按 PID 的 processlist 导出；当前 conf 已关闭易变列。勿随意打开 `[irq]` 等到 CSV。

**磁盘涨太快**  
1s 间隔 CSV 较大；可 `./scripts/record-sys-profiling.sh 5`，或定期清 `data/csv/` 旧文件。

## 10. 宿主机重新打包

```bash
cd ~/Work/glances-persist
chmod +x scripts/*.sh
mkdir -p data/csv data/plots

cd ~/Work
tar -czf glances-persist.tar.gz \
  --exclude='glances-persist/data/csv/*' \
  --exclude='glances-persist/data/plots/*' \
  --exclude='glances-persist/**/__pycache__' \
  --exclude='glances-persist/**/*.pyc' \
  glances-persist

ls -lh glances-persist.tar.gz
```

然后按第 2 节 `scp` 上板。
